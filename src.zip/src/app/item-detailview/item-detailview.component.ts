import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item-detailview',
  templateUrl: './item-detailview.component.html',
  styleUrls: ['./item-detailview.component.scss']
})
export class ItemDetailviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
