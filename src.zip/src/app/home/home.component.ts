import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"]
})
export class HomeComponent implements OnInit {
  constructor() {}

  items: Array<any> = [
    {
      item_name: "Nexas 48A",
      image: "assets/images/phone4.jpg",
      price: 12499
    },
    {
      item_name: "Nexas 48A",
      image: "assets/images/phone4.jpg",
      price: 12499
    },
    {
      item_name: "Nexas 48A",
      image: "assets/images/phone4.jpg",
      price: 12499
    },

    {
      item_name: "Samsung Smart watch",
      image: "assets/images/watch2.jpg",
      price: 15499
    },

    {
      item_name: "Mi watch with Android",
      image: "assets/images/watch3.jfif",
      price: 12499
    },

    {
      item_name: "Mi watch with Android",
      image: "assets/images/watch2.jpg",
      price: 10499
    },

    {
      item_name: "Philips Trimmer",
      image: "assets/images/trimmer1.jpg",
      price: 1500
    },

    {
      item_name: "Nova Trimmer",
      image: "assets/images/trimmer2.jfif",
      price: 1400
    },

    {
      item_name: "Panasonic Trimmer",
      image: "assets/images/trimmer3.jfif",
      price: 1350
    },
    {
      item_name: "Samsung Series 4 80cm (32) HD Ready LED Smart TV",
      image: "assets/images/tv1.jpg",
      price: 25000
    },
    {
      item_name: "Mi LED Smart TV 4A PRO 80 cm (32) with Android",
      image: "assets/images/tv3.jfif",
      price: 30000
    },
    {
      item_name: "Onida LEB Smart Tv (32) inches",
      image: "assets/images/tv1.jpg",
      price: 32000
    },
    {
      item_name: "Philips Headphones",
      image: "assets/images/headphones1.jfif",
      price: 2000
    },

    {
      item_name: "Mpow 059 Headphones",
      image: "assets/images/headphones.jpg",
      price: 1400
    },

    {
      item_name: "Noise free Headphones",
      image: "assets/images/headphones3.jfif",
      price: 3000
    },
    {
      item_name: "Noise free Headphones",
      image: "assets/images/headphones3.jfif",
      price: 3000
    },
    {
      item_name: "Noise free Headphones",
      image: "assets/images/headphones3.jfif",
      price: 3000
    },
    {
      item_name: "Noise free Headphones",
      image: "assets/images/headphones3.jfif",
      price: 3000
    }
  ];
  ngOnInit() {}
}
