import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-user-cart",
  templateUrl: "./user-cart.component.html",
  styleUrls: ["./user-cart.component.scss"]
})
export class UserCartComponent implements OnInit {
  constructor() {}

  items: Array<any> = [
    {
      image: "assets/images/tv1.jpg",
      item_name:
        "LG All-in-One 126cm (50 inch) Ultra HD (4K) LED Smart TV 2019 Edition 50UM7290PTD Seller: OmniTechRetail"
    },

    {
      image: "assets/images/trimmer1.jpg",
      item_name:
        "Ustraa Chrome - Corded & Cordless Titanium Coated Stainless Steel Blade Beard Trimmer with Lithium-ion Battery"
    },
    {
      image: "assets/images/watch1.jpg",
      item_name:
        "Muzili Smart Watch 1.3'' Large Color Full Touch Screen IP68 Waterproof Fitness watch"
    },
    {
      image: "assets/images/shirt.jpeg",
      item_name:
        "LG All-in-One 126cm (50 inch) Ultra HD (4K) LED Smart TV 2019 Edition 50UM7290PTD Seller: OmniTechRetail"
    }
  ];

  ngOnInit() {}
}
